# Coursework_Calculator

The Coursework Calculator automatically calculates the dedicated amount of hours for each course and their respective goals based on user input values.

 * Course Data for contact and idependent hours
 * Total calculations for hours generated
 * Total for class meetings
 * Discussions & Media
 * Hours spent studying
 * Hours spent on projects
 * Quizzes & Exams
 * Reflective & Narrative Essays
 * Research Papers & Case Studies
 * Web Articles & Textbooks


![SoPAppIntro](https://user-images.githubusercontent.com/91149920/164145959-d389a30c-b125-4d7d-940b-75f2a57d51bd.png)
![SoPACourseApp](https://user-images.githubusercontent.com/91149920/164145962-59dc3652-8d90-4b80-b324-6b97b0996459.png)
